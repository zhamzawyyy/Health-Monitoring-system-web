// Lightweight source verification for this dependency-free interface.
import {readdir,readFile,access} from 'node:fs/promises';
import {join,dirname,resolve} from 'node:path';
import {spawnSync} from 'node:child_process';
async function walk(dir){for(const entry of await readdir(dir,{withFileTypes:true})){const path=join(dir,entry.name);if(entry.isDirectory())await walk(path);else if(path.endsWith('.js')){const result=spawnSync(process.execPath,['--check',path],{encoding:'utf8'});if(result.status!==0)throw Error(result.stderr);const source=await readFile(path,'utf8');for(const match of source.matchAll(/from\s+['"](.+?)['"]/g)){await access(resolve(dirname(path),match[1]));}}}}
await walk('src');const html=await readFile('index.html','utf8');for(const match of html.matchAll(/(?:src|href)="(src\/[^"]+)"/g))await access(match[1]);const ids=[...html.matchAll(/\bid="([^"]+)"/g)].map(m=>m[1]);if(new Set(ids).size!==ids.length)throw Error('Duplicate HTML IDs');console.log('Verified JavaScript syntax, module imports, HTML asset references, and unique element IDs.');
