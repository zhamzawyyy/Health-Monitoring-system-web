# ORBITAL — Astronaut health interface

A monochrome, responsive UI prototype. Plain HTML, CSS, and JavaScript modules; no dependencies or build step.

## Preview

Run `python3 -m http.server 5173` and open http://localhost:5173. If Node.js is installed, `npm run dev` starts the same server. Python 3 is required for the local static server. Run `npm run check` to verify source syntax and local references. Use an HTTP server rather than opening index.html directly, because the app uses ES modules.

## Project structure

- `index.html` — accessible single-page structure
- `src/app.js` — module initialization and shared metric dialog
- `src/styles/base.css` — theme tokens and shared controls
- `src/styles/layout.css` — shared page layout
- `src/styles/compact.css` — compact dashboard grid and responsive sizing
- `src/shared/icons.js` — local SVG icon library
- `src/modules/ambient/` — procedural moon, animated starfield, optional cabin ambience
- `src/modules/dashboard/` — fixture data, vital cards, charts, routine checklist
- `src/modules/checkin/` — voice-first check-in, browser transcription, and animated optional writing dialog
- `src/modules/mission/log.js` — session notes and plain-text export
- `scripts/check.mjs` — source integrity checks

## Design behavior

One page with no sidebar or navigation tabs. A compact mission heading sits above a two-column workspace: a voice-first check-in on the left, and sample vitals plus a trend chart on the right. The routine checklist is a compact row beneath them. Smaller screens stack the sections without clipping content. Metric cards open explanations without leaving the page. Saved notes live in a compact expandable section below the voice control and can be exported. The keyboard icon opens an animated, keyboard-accessible writing dialog with a 156px minimum-height field. Closing it preserves the draft. The chart switches between 24-hour and 7-day sample data.

Sound starts only after the user enables it, using low-volume filtered noise generated with Web Audio. Motion respects reduced-motion settings and can be paused manually. The background has continuously drifting stars, a moving monochrome glow, and orbit motion. Background animation and sound pause in hidden tabs.

## Scope

Design only: no backend, AI diagnosis, actual support connection, authentication, sensor integration, or medical guidance. All readings and mission details are fictional fixtures. Notes exist in memory only and reset on page reload. No external fonts, tracking, images, or audio requests.

Edit theme variables in `base.css`, display fixtures in `dashboard/data.js`, and each module's files independently. Mission date and crew details are intentionally fixed demo content.

## Voice input

The central floating space orb is decorative, not clickable. A small Enable mic / Mic on control starts or stops hands-free listening. With microphone permission already granted, the page attempts to start automatically, unless the user switched it off in this tab. Otherwise, the browser requires a one-time enable/permission step. Browsers without microphone permission queries keep the explicit enable control.

SpeechRecognition runs continuously and reconnects after natural endings or silence, without a time limit or a tap for each phrase. Finalized phrases save automatically to session notes; interim words are previewed but never saved as final text. The UI shows Listening only after the browser confirms recognition has started. The orb animation indicates state, not measured audio volume.

Opening Write or hiding the page suspends recognition; closing Write or returning resumes it if the microphone is still enabled. Turning it off cancels pending restarts. Permission, network, device, and repeated immediate-disconnection failures stop automatic retries and show a clear message. Changing the speaking language requires turning the microphone off first.

Only the on/off preference is kept in sessionStorage. Notes and transcripts stay in memory and reset on reload. Speech services may process audio online, and support varies by browser; this is not an offline or mission-ready voice system. No app-side audio recording, diagnosis, or generated assistant reply is provided.

API references:
- https://developer.mozilla.org/en-US/docs/Web/API/SpeechRecognition
- https://developer.mozilla.org/en-US/docs/Web/API/SpeechRecognition/end_event
