import {
  vitals,routines
} from './data.js';
import {
  icon
} from '../../shared/icons.js';
export const sparkline = points => `<svg class="sparkline" viewBox="0 0 100 40" preserveAspectRatio="none" aria-hidden="true"><polyline points="${points}" fill="none" stroke="#c4c7d0" stroke-width="1.2"/></svg>`;
export function initDashboard(showDialog) {
  document.querySelector('#vital-cards').innerHTML=vitals.map(v=>`<button class="vital-card panel" data-metric="${v.id}" aria-label="${v.name}: ${v.value} ${v.unit}. View explanation"><span class="vital-label">${icon(v.icon)}${v.name}<span class="metric-arrow">${icon('arrowUpRight')}</span></span><span class="vital-value">${v.value}<small>${v.unit}</small></span>${sparkline(v.points)}<span class="vital-status"><span class="status-dot"></span>${v.note}</span></button>`).join('');
  document.querySelectorAll('[data-metric]').forEach(button=>button.addEventListener('click',()=> {
    const v=vitals.find(v=>v.id===button.dataset.metric);
    showDialog(`<h2>${v.name}</h2><div class="dialog-reading">${v.value} <small>${v.unit}</small></div><p>${v.description}</p><p>Demo data · No sensor is connected.</p>`);
  }));
  document.querySelector('#routine-list').innerHTML=routines.map((r,i)=>`<label class="routine-row"><input type="checkbox" aria-label="Mark ${r.title.toLowerCase()} complete" data-routine="${i}"><span><strong>${r.title}</strong><small>${r.description}</small></span><span>${r.time}</span></label>`).join('');
  document.querySelector('#routine-list').addEventListener('change',()=>document.querySelector('#routine-count').textContent=`${document.querySelectorAll('[data-routine]:checked').length} / 3`);
  document.querySelectorAll('[data-range]').forEach(b=>b.addEventListener('click',()=>renderChart(b.dataset.range)));
  renderChart('day');
}
function renderChart(range) {
  const week=range==='week';
  const values=week?[71,69,70,67,69,66,68]:[66,65,68,67,72,68,69,66,65,67,69,68,67,70,68,69,66,68,67,68,66,68,69,68];
  const points=values.map((v,i)=>`${i*600/(values.length-1)},${70-(v-63)*6}`).join(' ');
  document.querySelector('#trend-chart').innerHTML=`<svg viewBox="0 0 600 80" preserveAspectRatio="none" role="img" aria-label="${week?'Seven day':'24 hour'} sample resting heart rate chart, ranging from ${Math.min(...values)} to ${Math.max(...values)} beats per minute"><defs><linearGradient id="chart-fill" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#fff" stop-opacity=".11"/><stop offset="100%" stop-color="#fff" stop-opacity="0"/></linearGradient></defs><polygon points="0,80 ${points} 600,80" fill="url(#chart-fill)"/><polyline points="${points}" fill="none" stroke="#c3c5ce" stroke-width="1.6" vector-effect="non-scaling-stroke"/></svg>`;
  document.querySelector('#chart-axis').innerHTML=(week?['SAT','SUN','MON','TUE','WED','THU','FRI']:['00:00','04:00','08:00','12:00','16:00','20:00','23:00']).map(t=>`<span>${t}</span>`).join('');
  document.querySelector('#trend-value').innerHTML=`${week?'69':'68'} <small>bpm</small>`;
  document.querySelector('#trend-description').textContent=week?'This week’s sample average':'Today’s sample average';
  document.querySelectorAll('[data-range]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.range===range)));
}
