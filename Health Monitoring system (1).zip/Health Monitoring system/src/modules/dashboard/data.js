// All readings are invented display fixtures, never interpreted as medical results.
export const vitals = [
{
  id:'heart',name:'Heart rate',value:'68',unit:'bpm',icon:'heart',note:'At rest',description:'The number of times your heart beats in one minute. This preview shows a sample reading taken at rest.',points:'0,23 12,21 20,23 27,8 34,29 41,15 48,21 60,21 69,18 80,21 90,16 100,20'
},
{
  id:'oxygen',name:'Blood oxygen',value:'98',unit:'%',icon:'droplet',note:'Sample reading',description:'The estimated share of oxygen-carrying hemoglobin in your blood. A connected sensor would provide this reading in a working product.',points:'0,20 12,21 24,19 35,21 47,16 60,18 73,14 84,17 100,14'
},
{
  id:'temperature',name:'Body temperature',value:'36.6',unit:'°C',icon:'temperature',note:'Sample reading',description:'A sample body temperature in degrees Celsius. The prototype does not connect to a thermometer or evaluate your health.',points:'0,23 13,20 22,22 34,18 43,19 55,16 68,18 80,15 90,18 100,15'
},
{
  id:'sleep',name:'Sleep last night',value:'7.4',unit:'hrs',icon:'moon',note:'Last sleep session',description:'A sample total of seven hours and twenty-four minutes of sleep. A working product could bring together sleep records here.',points:'0,25 8,25 8,14 22,14 22,22 34,22 34,8 49,8 49,18 62,18 62,12 79,12 79,20 89,20 89,8 100,8'
}
];
export const routines = [ {
  title:'Take a quiet moment',description:'A little space to clear your mind',time:'2 min'
}, {
  title:'Log your water',description:'A reminder to record your intake',time:'1 min'
}, {
  title:'Complete your daily check-in',description:'Notice how you feel today',time:'1 min'
}];
