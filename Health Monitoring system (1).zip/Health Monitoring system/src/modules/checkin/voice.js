import { icon } from '../../shared/icons.js';
import { createSpeechSession } from './speech-session.js';

export function initVoice({ saveCheckin }) {
  const Recognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  const button = document.querySelector('#voice-toggle');
  const stage = document.querySelector('#voice-stage');
  const status = document.querySelector('#voice-status');
  const title = document.querySelector('#voice-title');
  const language = document.querySelector('#voice-language');
  const draft = document.querySelector('#voice-draft');
  const transcript = document.querySelector('#voice-transcript');
  let writing = false;
  let interacted = false;
  let permission;
  const preferenceKey = 'orbital-mic-preference';

  // Only a mic preference is retained; speech and notes remain session-memory only.
  function preference(value) {
    try {
      if (value !== undefined) sessionStorage.setItem(preferenceKey, value);
      return sessionStorage.getItem(preferenceKey);
    } catch { return null; }
  }

  const session = createSpeechSession({
    Recognition,
    language: () => language.value,
    onState(state, message) {
      const listening = state === 'listening';
      const enabled = session.enabled;
      stage.classList.toggle('is-listening', listening);
      stage.classList.toggle('is-connecting', state === 'connecting');
      button.setAttribute('aria-pressed', String(enabled));
      button.setAttribute('aria-label', enabled ? 'Turn microphone off' : 'Enable microphone');
      button.innerHTML = `${icon('mic')}<span>${enabled ? 'Mic on' : 'Enable mic'}</span>`;
      language.disabled = enabled || !Recognition;
      title.textContent = listening ? 'I’m listening.' : state === 'connecting' ? 'Connecting to you…' : state === 'paused' ? 'A quiet moment.' : 'A space to be heard.';
      status.textContent = message;
      if (state === 'error') preference('off');
    },
    onWords(text) {
      transcript.textContent = text;
      draft.hidden = !text;
    },
    onFinal(text) { saveCheckin(text, null, { quiet: true }); }
  });

  if (!Recognition) {
    button.disabled = true;
    language.disabled = true;
    status.textContent = 'Voice isn’t supported in this browser. Write is still available.';
  }

  button.addEventListener('click', () => {
    interacted = true;
    if (session.enabled) {
      preference('off');
      session.disable();
    } else {
      preference('on');
      session.enable();
    }
  });

  function syncVisibility() {
    if (document.hidden || writing) session.pause();
    else session.resume();
  }
  document.addEventListener('visibilitychange', syncVisibility);
  addEventListener('pagehide', () => session.pause());
  addEventListener('pageshow', syncVisibility);

  // Already granted permission allows hands-free entry. Never bypass a prompt
  // or re-enable after the user deliberately switched the mic off in this tab.
  async function resumeWithPermission() {
    if (!Recognition || !navigator.permissions) return;
    try {
      permission = await navigator.permissions.query({ name: 'microphone' });
      permission.addEventListener('change', () => {
        if (permission.state !== 'granted' && session.enabled) {
          session.disable();
          status.textContent = 'Microphone permission changed. Enable your mic to continue.';
        }
      });
      if (!interacted && permission.state === 'granted' && preference() !== 'off') {
        if (document.hidden || writing) session.pause();
        session.enable();
      }
    } catch {
      // Some browsers do not expose microphone permission queries.
      // Their one-time Enable mic action remains available.
    }
  }
  resumeWithPermission();
  return {
    pauseForWriting() { writing = true; syncVisibility(); },
    resumeAfterWriting() { writing = false; syncVisibility(); }
  };
}
