import { addEntry } from '../mission/log.js';
import { initVoice } from './voice.js';

export function initCheckin(toast) {
  const form = document.querySelector('#feeling-form');
  const input = document.querySelector('#feeling-input');
  const dialog = document.querySelector('#writing-dialog');
  const opener = document.querySelector('#open-writing');
  let closeTimer;

  function saveCheckin(note, energy, { quiet = false } = {}) {
    addEntry(energy ? `Check-in · ${energy} energy` : 'A moment to check in', note);
    const feedback = document.querySelector('#feeling-feedback');
    feedback.hidden = false;
    feedback.textContent = 'Check-in saved in your session notes.';
    const routine = document.querySelector('[data-routine="2"]');
    routine.checked = true;
    routine.dispatchEvent(new Event('change', { bubbles: true }));
    if (!quiet) toast('Check-in saved for this session.');
  }

  function resizeInput() {
    input.style.height = 'auto';
    input.style.height = `${Math.min(input.scrollHeight, 300)}px`;
  }

  function openWriting(text) {
    voice.pauseForWriting();
    if (typeof text === 'string') {
      input.value = text;
      input.setCustomValidity('');
    }
    if (dialog.open) return;
    clearTimeout(closeTimer);
    dialog.classList.remove('closing');
    dialog.showModal();
    resizeInput();
    input.focus();
  }

  // Native dialog provides focus trapping; Escape/backdrop use the same exit animation.
  function closeWriting() {
    if (!dialog.open || dialog.classList.contains('closing')) return;
    dialog.classList.add('closing');
    const duration = matchMedia('(prefers-reduced-motion: reduce)').matches ? 0 : 160;
    closeTimer = setTimeout(() => {
      dialog.close();
      voice.resumeAfterWriting();
      dialog.classList.remove('closing');
      opener.focus({ preventScroll: true });
    }, duration);
  }

  const voice = initVoice({ saveCheckin, openWriting });
  opener.addEventListener('click', () => openWriting());
  document.querySelector('#close-writing').addEventListener('click', closeWriting);
  dialog.addEventListener('cancel', event => {
    event.preventDefault();
    closeWriting();
  });
  dialog.addEventListener('click', event => {
    if (event.target !== dialog) return;
    const rect = dialog.getBoundingClientRect();
    if (event.clientX < rect.left || event.clientX > rect.right ||
        event.clientY < rect.top || event.clientY > rect.bottom) closeWriting();
  });
  input.addEventListener('input', () => {
    input.setCustomValidity('');
    resizeInput();
  });
  form.addEventListener('submit', event => {
    event.preventDefault();
    const note = input.value.trim();
    if (!note) {
      input.setCustomValidity('Add a few words about how you feel.');
      input.reportValidity();
      return;
    }
    saveCheckin(note, new FormData(form).get('energy'));
    form.reset();
    input.style.height = '';
    closeWriting();
  });
}
