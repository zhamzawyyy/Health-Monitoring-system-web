// One recognition instance per connection avoids stale events after stop/restart.
// Dependencies are injectable so microphone lifecycle can be checked without audio.
export function createSpeechSession({ Recognition, language, onState, onWords, onFinal,
  schedule = setTimeout, cancel = clearTimeout, now = Date.now }) {
  let enabled = false;
  let suspended = false;
  let engine = null;
  let retry = null;
  let quickEnds = 0;

  function disconnect() {
    cancel(retry);
    retry = null;
    const previous = engine;
    engine = null;
    if (previous) previous.abort();
  }

  function fail(message) {
    enabled = false;
    disconnect();
    onState('error', message);
  }

  function connect() {
    if (!enabled || suspended || engine) return;
    if (!Recognition) return fail('Voice is unavailable in this browser. Write is still available.');
    const current = new Recognition();
    const startedAt = now();
    const delivered = new Set();
    engine = current;
    current.lang = language();
    current.continuous = true;
    current.interimResults = true;
    current.maxAlternatives = 1;
    onState('connecting', 'Connecting your microphone…');

    current.onstart = () => {
      if (engine === current) onState('listening', 'Listening continuously. Take your time.');
    };
    current.onresult = event => {
      if (engine !== current || !enabled || suspended) return;
      const fresh = [];
      const words = [];
      for (let index = 0; index < event.results.length; index++) {
        const result = event.results[index];
        const text = result[0].transcript.trim();
        words.push(text);
        if (result.isFinal && !delivered.has(index)) {
          delivered.add(index);
          if (text) fresh.push(text);
        }
      }
      quickEnds = 0;
      onWords(words.join(' ').trim());
      // Finalized speech is saved automatically. No save button is required.
      if (fresh.length) onFinal(fresh.join(' '));
    };
    current.onerror = event => {
      if (engine !== current) return;
      // Silence is normal for hands-free use; onend reconnects after it.
      if (event.error === 'no-speech') return;
      const messages = {
        'not-allowed': 'Allow microphone access, then enable your mic.',
        'service-not-allowed': 'Voice is unavailable here. Write is still available.',
        'audio-capture': 'No microphone was found. Connect one, then enable your mic.',
        'network': 'Voice connection lost. Enable your mic to reconnect.',
        'language-not-supported': 'This language is unavailable. Choose another, then enable your mic.'
      };
      fail(messages[event.error] || 'Voice stopped. Enable your mic to reconnect.');
    };
    current.onend = () => {
      if (engine !== current) return;
      engine = null;
      if (!enabled || suspended) return;
      quickEnds = now() - startedAt < 1500 ? quickEnds + 1 : 0;
      if (quickEnds >= 4) return fail('The browser could not keep voice connected. Enable your mic to retry.');
      onState('connecting', 'Reconnecting. Your saved words are safe.');
      retry = schedule(connect, 350 + quickEnds * 400);
    };
    try { current.start(); }
    catch { fail('The browser needs you to enable the microphone again.'); }
  }

  return {
    get enabled() { return enabled; },
    enable() { enabled = true; quickEnds = 0; connect(); },
    disable() { enabled = false; disconnect(); onState('off', 'Microphone off. Enable it whenever you’re ready.'); },
    pause() {
      suspended = true;
      disconnect();
      if (enabled) onState('paused', 'Listening paused while you’re away or writing.');
    },
    resume() { suspended = false; if (enabled) connect(); }
  };
}
